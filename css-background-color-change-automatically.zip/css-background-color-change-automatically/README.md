# CSS background-color change automatically

A Pen created on CodePen.io. Original URL: [https://codepen.io/jishnu10/pen/YzaYXjz](https://codepen.io/jishnu10/pen/YzaYXjz).

